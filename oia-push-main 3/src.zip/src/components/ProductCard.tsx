import { Card } from "@/components/ui/card";
import { trackViewContent } from '@/services/facebookPixelService';
import { useUtm } from '@/hooks/useUtm';

export interface ProductCardProps {
  id: string;
  name: string;
  description: string;
  price: number;
  discountedPrice?: number;
  image: string;
  badge?: string;
  badgeColor?: string;
  onViewDetails: (productId: string) => void;
}

export function ProductCard({ 
  id, 
  name, 
  description, 
  price, 
  discountedPrice, 
  image, 
  badge,
  badgeColor = "primary",
  onViewDetails 
}: ProductCardProps) {
  // Calcular desconto percentual
  const discountPercentage = discountedPrice
    ? Math.round(((price - discountedPrice) / price) * 100)
    : 0;

  // Determinar a cor do badge baseado na propriedade badgeColor
  const getBadgeColor = () => {
    switch (badgeColor) {
      case 'red': return 'bg-red-500';
      case 'orange': return 'bg-orange-500';
      case 'green': return 'bg-green-500';
      case 'blue': return 'bg-blue-500';
      case 'pink': return 'bg-pink-500';
      case 'purple': return 'bg-purple-500';
      default: return 'bg-primary';
    }
  };

  const utm = useUtm();

  // Handler para visualizar detalhes do produto e disparar evento ViewContent
  const handleViewDetails = (productId: string) => {
    trackViewContent({
      content_type: 'product',
      content_ids: [id],
      content_name: name,
      currency: 'BRL',
      value: discountedPrice || price,
      utm: utm.getAllUtmParams(),
    }, utm.getAllUtmParams());
    onViewDetails(productId);
  };

  return (
    <Card 
      className="overflow-hidden border border-gray-200 hover:border-gray-300 transition-all duration-300 cursor-pointer"
      onClick={() => handleViewDetails(id)}
    >
      <div className="flex p-3 gap-3">
        {/* Imagem do produto */}
        <div className="w-24 h-24 flex-shrink-0 rounded-md overflow-hidden">
          <img 
            src={image} 
            alt={name}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
        
        {/* Conteúdo */}
        <div className="flex-1 min-w-0 flex flex-col">
          {/* Badge (se existir) */}
          {badge && (
            <div className={`${getBadgeColor()} text-white px-2 py-0.5 rounded-full text-xs font-bold mb-1 self-start`}>
              {badge}
            </div>
          )}
          
          {/* Nome do produto */}
          <h3 className="font-bold text-sm text-foreground mb-1 line-clamp-2">
            {name}
          </h3>
          
          {/* Descrição */}
          {description && (
            <p className="text-xs text-muted-foreground mb-auto line-clamp-2">
              {description}
            </p>
          )}
          
          {/* Preços */}
          <div className="mt-1">
            <div className="flex items-center gap-2 flex-wrap">
              {discountedPrice && (
                <>
                  <span className="text-red-500 line-through text-xs">
                    R$ {price.toFixed(2).replace('.', ',')}
                  </span>
                  <span className="font-bold text-green-600">
                    R$ {discountedPrice.toFixed(2).replace('.', ',')}
                  </span>
                </>
              )}
              {!discountedPrice && (
                <span className="font-bold">
                  R$ {price.toFixed(2).replace('.', ',')}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}