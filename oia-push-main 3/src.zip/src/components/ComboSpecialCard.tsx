import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Star, Users, TrendingUp, AlertTriangle } from "lucide-react";

export interface ComboSpecialCardProps {
  combo: {
    id: string;
    name: string;
    description: string;
    price: number;
    discountedPrice?: number;
    image: string;
    badge?: string;
    urgency?: string;
    socialProof?: string;
    scarcity?: string;
    specialStyle?: boolean;
    badgeColor?: string;
  };
  onViewDetails: (productId: string) => void;
}

export function ComboSpecialCard({ combo, onViewDetails }: ComboSpecialCardProps) {
  // Calcular desconto percentual
  const discountPercentage = combo.discountedPrice
    ? Math.round(((combo.price - combo.discountedPrice) / combo.price) * 100)
    : 0;

  // Determinar a cor do badge baseado na propriedade badgeColor
  const getBadgeColor = () => {
    switch (combo.badgeColor) {
      case 'red': return 'bg-red-500';
      case 'orange': return 'bg-orange-500';
      case 'green': return 'bg-green-500';
      case 'blue': return 'bg-blue-500';
      case 'pink': return 'bg-pink-500';
      case 'purple': return 'bg-purple-500';
      default: return 'bg-primary';
    }
  };

  return (
    <Card className={`overflow-hidden border ${combo.specialStyle ? 'border-red-500/30 shadow-lg shadow-red-500/10' : 'border-gray-200'}`}>
      <div className="relative">
        {/* Imagem do produto */}
        <div 
          className="h-48 bg-cover bg-center" 
          style={{ backgroundImage: `url(${combo.image})` }}
        />
        
        {/* Overlay para melhorar contraste */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        
        {/* Badge de desconto */}
        <div className="absolute top-3 right-3 bg-red-500 text-white px-2 py-1 rounded-md font-bold text-sm">
          {discountPercentage}% OFF
        </div>
        
        {/* Badge personalizado */}
        {combo.badge && (
          <div className={`absolute top-3 left-3 ${getBadgeColor()} text-white px-3 py-1 rounded-md font-bold text-xs max-w-[70%]`}>
            {combo.badge}
          </div>
        )}
        
        {/* Preço */}
        <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md">
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 line-through">
              R$ {combo.price.toFixed(2).replace('.', ',')}
            </span>
            <span className="text-green-600 font-bold">
              R$ {combo.discountedPrice?.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        {/* Nome do produto */}
        <h3 className="font-bold text-lg mb-2 line-clamp-2">{combo.name}</h3>
        
        {/* Descrição */}
        <p className="text-sm text-gray-500 mb-4 line-clamp-2">{combo.description}</p>
        
        {/* Indicadores de urgência */}
        {combo.urgency && (
          <div className="flex items-center gap-2 mb-3 text-xs text-red-600 font-medium">
            <Clock className="h-3 w-3" />
            <span>{combo.urgency}</span>
          </div>
        )}
        
        {/* Prova social */}
        {combo.socialProof && (
          <div className="flex items-center gap-2 mb-3 text-xs text-blue-600 font-medium">
            <Star className="h-3 w-3" />
            <span>{combo.socialProof}</span>
          </div>
        )}
        
        {/* Escassez */}
        {combo.scarcity && (
          <div className="flex items-center gap-2 mb-3 text-xs text-amber-600 font-medium">
            <AlertTriangle className="h-3 w-3" />
            <span>{combo.scarcity}</span>
          </div>
        )}
        
        {/* Botão de ação */}
        <Button 
          onClick={() => onViewDetails(combo.id)} 
          className="w-full mt-2"
          variant={combo.specialStyle ? "destructive" : "default"}
        >
          Ver Detalhes
        </Button>
      </div>
    </Card>
  );
} 