import { FC, useEffect, useRef, useState } from 'react';
import { MapPin } from 'lucide-react';

interface GoogleMapProps {
  address: {
    lat: number;
    lng: number;
  };
  apiKey: string;
  className?: string;
}

// Componente interno que renderiza o mapa
const MapComponent: FC<{ center: google.maps.LatLngLiteral; zoom: number; className?: string }> = ({ 
  center, 
  zoom,
  className = ''
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [marker, setMarker] = useState<google.maps.Marker | null>(null);
  const [mapError, setMapError] = useState<boolean>(false);

  useEffect(() => {
    // Log para debug
    console.log('MapComponent montado com centro:', center);
    
    if (ref.current && !map && window.google && window.google.maps) {
      try {
        // Inicializar o mapa
        const mapInstance = new window.google.maps.Map(ref.current, {
          center,
          zoom,
          disableDefaultUI: false,
          zoomControl: true,
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
        });
        setMap(mapInstance);

        // Adicionar marcador
        const markerInstance = new window.google.maps.Marker({
          position: center,
          map: mapInstance,
          animation: window.google.maps.Animation.DROP,
        });
        setMarker(markerInstance);
        
        console.log('Mapa inicializado com sucesso');
      } catch (error) {
        console.error('Erro ao inicializar o mapa:', error);
        setMapError(true);
      }
    }
  }, [ref, map, center, zoom]);

  // Atualizar a posição do marcador quando as coordenadas mudam
  useEffect(() => {
    if (marker && map) {
      try {
        marker.setPosition(center);
        map.panTo(center);
      } catch (error) {
        console.error('Erro ao atualizar posição do mapa:', error);
      }
    }
  }, [center, marker, map]);

  if (mapError) {
    return <MapErrorFallback className={className} />;
  }

  return <div ref={ref} className={`w-full h-full ${className}`} />;
};

// Componente de fallback enquanto o mapa carrega
const MapLoadingFallback: FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`w-full h-full bg-gray-100 flex items-center justify-center ${className}`}>
      <div className="animate-pulse text-gray-500">Carregando mapa...</div>
    </div>
  );
};

// Componente de erro caso o mapa falhe ao carregar
const MapErrorFallback: FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`w-full h-full bg-gray-100 flex flex-col items-center justify-center ${className}`}>
      <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mb-2">
        <MapPin className="w-6 h-6 text-gray-400" />
      </div>
      <div className="text-gray-500 text-center px-4">
        <p className="font-medium mb-1">Não foi possível carregar o mapa</p>
        <p className="text-sm">Sua localização foi registrada com sucesso</p>
      </div>
    </div>
  );
};

// Componente visual de mapa estático para fallback
const StaticMapFallback: FC<{ address: { lat: number; lng: number }; className?: string }> = ({ 
  address, 
  className = '' 
}) => {
  return (
    <div className={`relative w-full h-full bg-gray-100 ${className}`}>
      {/* Simulação visual de mapa */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-green-50 to-blue-50">
        {/* Simulação de ruas */}
        <div className="absolute top-1/3 left-0 w-full h-0.5 bg-gray-300"></div>
        <div className="absolute top-2/3 left-0 w-full h-0.5 bg-gray-300"></div>
        <div className="absolute left-1/4 top-0 w-0.5 h-full bg-gray-300"></div>
        <div className="absolute left-2/3 top-0 w-0.5 h-full bg-gray-300"></div>
        
        {/* Pin de localização vermelho */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="w-8 h-8 bg-red-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center">
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
        </div>
        
        {/* Logo Google */}
        <div className="absolute bottom-2 left-2">
          <span className="text-xs text-blue-600 font-bold">Maps</span>
        </div>
      </div>
    </div>
  );
};

// Componente principal que exportamos
export const GoogleMap: FC<GoogleMapProps> = ({ address, apiKey, className = '' }) => {
  const [googleLoaded, setGoogleLoaded] = useState<boolean>(false);
  const [apiError, setApiError] = useState<boolean>(false);
  
  // Verificar se o Google Maps já está carregado
  useEffect(() => {
    const checkGoogleMapsLoaded = () => {
      if (window.google && window.google.maps) {
        console.log('Google Maps API já está carregada');
        setGoogleLoaded(true);
        return true;
      }
      return false;
    };
    
    // Verificar imediatamente
    if (checkGoogleMapsLoaded()) return;
    
    // Configurar um listener para o evento de carregamento do Google Maps
    const originalInitMap = window.initMap;
    window.initMap = () => {
      // Chamar a função original se existir
      if (originalInitMap) originalInitMap();
      
      console.log('Google Maps API carregada via callback');
      setGoogleLoaded(true);
    };
    
    // Verificar periodicamente se o Google Maps foi carregado
    const intervalId = setInterval(() => {
      if (checkGoogleMapsLoaded()) {
        clearInterval(intervalId);
      }
    }, 500);
    
    // Timeout para caso o Google Maps não carregue
    const timeoutId = setTimeout(() => {
      if (!googleLoaded) {
        console.error('Timeout ao aguardar carregamento do Google Maps');
        setApiError(true);
        clearInterval(intervalId);
      }
    }, 10000);
    
    return () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
      window.initMap = originalInitMap;
    };
  }, []);

  // Log para debug
  useEffect(() => {
    console.log('GoogleMap montado com endereço:', address);
    console.log('API Key:', apiKey);
  }, [address, apiKey]);

  // Detectar erros de API
  useEffect(() => {
    const checkApiErrors = () => {
      const errorElements = document.querySelectorAll('.gm-err-container');
      if (errorElements.length > 0) {
        console.error('Detectado erro na API do Google Maps');
        setApiError(true);
      }
    };

    // Verificar após um tempo para dar chance do erro aparecer
    const timer = setTimeout(checkApiErrors, 3000);
    return () => clearTimeout(timer);
  }, [googleLoaded]);

  // Capturar erros globais da API do Google Maps
  useEffect(() => {
    const handleGlobalError = (event: ErrorEvent) => {
      if (event.message.includes('Google Maps JavaScript API') || 
          event.message.includes('google is not defined')) {
        console.error('Erro global da API do Google Maps:', event);
        setApiError(true);
      }
    };

    window.addEventListener('error', handleGlobalError);
    return () => window.removeEventListener('error', handleGlobalError);
  }, []);

  // Se houver erro de API, mostrar o fallback estático
  if (apiError) {
    return <StaticMapFallback address={address} className={className} />;
  }

  // Se o Google Maps ainda não carregou, mostrar o loading
  if (!googleLoaded) {
    return <MapLoadingFallback className={className} />;
  }

  // Google Maps está carregado, mostrar o mapa
  return (
    <MapComponent 
      center={{ lat: address.lat, lng: address.lng }} 
      zoom={16}
      className={className}
    />
  );
};

export default GoogleMap; 