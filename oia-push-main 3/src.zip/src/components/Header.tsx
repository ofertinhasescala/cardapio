import { ShoppingCart, Info, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import { InfoModal } from "@/components/InfoModal";
import { ShoppingCart as Cart } from "@/components/ShoppingCart";
import { useCart } from "@/hooks/useCart";
import { useLocation } from "../hooks/LocationContext";
import DeliveryInfo from './DeliveryInfo';

export function Header() {
  const { city, state } = useLocation();
  const { cartCount } = useCart();
  const isStoreOpen = true; // Estado fixo para manter a loja sempre aberta
  
  // Formatação da localização
  const locationText = city && state 
    ? `${city}, ${state}` 
    : 'Buscando localização...';

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      {/* Seção Superior */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex flex-col">
          <h1 className="text-2xl font-extrabold text-foreground tracking-tighter">
            BRAZA BURGUER
          </h1>
          <div className="flex items-center gap-1 mt-0.5">
            <span className="text-muted-foreground">📍</span>
            <p className="text-xs text-muted-foreground font-medium truncate max-w-[200px]">
              {locationText}
            </p>
          </div>
        </div>

        {/* Logo */}
        <div className="flex-shrink-0">
          <img 
            src="/oia-burguer-logo.png" 
            alt="Logo Oia Burguer" 
            className="h-16 w-16"
            onError={(e) => {
              e.currentTarget.src = 'https://placehold.co/200x200/f8f9fa/6c757d?text=Oia+Burguer';
            }}
          />
        </div>
      </div>

      {/* Seção Inferior */}
      <div className="flex items-center justify-between px-4 py-2">
        {/* Informação de entrega e Info */}
        <div className="flex items-center space-x-4">
          <DeliveryInfo />
          <InfoModal>
            <button className="flex items-center gap-1 text-primary">
              <Info className="h-5 w-5" />
              <span className="font-medium text-xs">INFO</span>
            </button>
          </InfoModal>
        </div>

        {/* Status da Loja - Sempre aberto conforme solicitado */}
        <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full flex items-center gap-1 font-medium text-xs">
          <Store className="h-4 w-4" />
          <span>ABERTO</span>
        </div>
      </div>

      {/* Botão do carrinho flutuante com ShoppingCart */}
      <Cart>
        <Button 
          variant="default" 
          size="icon" 
          className="fixed bottom-4 right-4 bg-primary hover:bg-primary/90 text-primary-foreground rounded-full h-14 w-14 shadow-lg"
        >
          <ShoppingCart className="h-6 w-6" />
          {cartCount > 0 && (
            <div className="absolute -top-1 -right-1 bg-white text-primary text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center min-w-5 border border-primary">
              {cartCount > 99 ? '99+' : cartCount}
            </div>
          )}
        </Button>
      </Cart>
    </header>
  );
}