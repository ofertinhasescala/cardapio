import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  image: string;
  verified: boolean;
  date: string;
}

const reviews: Review[] = [
  {
    id: "1",
    name: "Carlos M",
    rating: 5,
    comment: "Mano do céu, que lanche bom! A carne veio no ponto certinho, muito top! 👏🔥",
    image: "https://burgzpedidos.com/images/rv12.jpg",
    verified: true,
    date: "2024-12-10"
  },
  {
    id: "2", 
    name: "Ana Paula S",
    rating: 5,
    comment: "Certeza que foi o melhor hambúrguer que já comi, vocês são incríveis demais! 👑🍔",
    image: "https://burgzpedidos.com/images/rv7.jpg",
    verified: true,
    date: "2024-12-09"
  },
  {
    id: "3",
    name: "Rodrigo L.",
    rating: 5, 
    comment: "Comi hoje pela primeira vez e já quero de novo kkkkk tá louco, que sabor!",
    image: "https://burgzpedidos.com/images/rv10.jpg",
    verified: true,
    date: "2024-12-08"
  },
  {
    id: "4",
    name: "Fernanda R",
    rating: 5,
    comment: "Pensa num hambúrguer caprichado... é esse aí! Chegou rápido e quentinho! 🔥",
    image: "https://burgzpedidos.com/images/rv1.jpg", 
    verified: true,
    date: "2024-12-07"
  },
  {
    id: "5",
    name: "Marcos P",
    rating: 5,
    comment: "O molho da casa é sem condições 🤤 queria um balde só dele kkk",
    image: "https://burgzpedidos.com/images/rv2.jpg",
    verified: true,
    date: "2024-12-06"
  },
  {
    id: "6",
    name: "Juliana C", 
    rating: 5,
    comment: "Atendimento top, lanche top, tudo top! Virei fã total! 😍",
    image: "https://burgzpedidos.com/images/rv3.jpg",
    verified: true,
    date: "2024-12-05"
  },
  {
    id: "7",
    name: "Rafael T",
    rating: 5,
    comment: "Bom, barato e entrega rápida. Não tem erro, semana que vem peço de novo!",
    image: "https://burgzpedidos.com/images/rv4.jpg",
    verified: true,
    date: "2024-12-04"
  },
  {
    id: "8",
    name: "Iana",
    rating: 5,
    comment: "Pedi pela primeira vez e todo mundo gostou, vamos pedir mais! 🍔",
    image: "https://burgzpedidos.com/images/rv5.jpg",
    verified: true,
    date: "2024-12-03"
  },
  {
    id: "9",
    name: "Gustavo",
    rating: 5,
    comment: "Inaugurou ontem aqui na minha cidade, pedi ontem e vou pedir hoje de novo rsrs! 😋",
    image: "https://burgzpedidos.com/images/rv6.jpg",
    verified: true,
    date: "2024-12-02"
  },
  {
    id: "10",
    name: "João Alves",
    rating: 5,
    comment: "Gostei muito mesmo! Sério kkk, superou as expectativas! 👏",
    image: "https://burgzpedidos.com/images/rv8.jpg",
    verified: true,
    date: "2024-12-01"
  },
  {
    id: "11",
    name: "Mari",
    rating: 5,
    comment: "Muito bom, estão de parabéns! Qualidade excepcional! ⭐",
    image: "https://burgzpedidos.com/images/rv9.jpg",
    verified: true,
    date: "2024-11-30"
  },
  {
    id: "12",
    name: "Ana",
    rating: 5,
    comment: "Top demais, comendo bem e pagando barato! Melhor custo-benefício! 💰",
    image: "https://burgzpedidos.com/images/rv11.jpg",
    verified: true,
    date: "2024-11-29"
  }
];

// Função auxiliar para formatar data
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
};

// Componente para exibir as estrelas de avaliação
const RatingStars = ({ rating }: { rating: number }) => {
  return (
    <div className="flex">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className="text-yellow-400 text-sm">★</span>
      ))}
    </div>
  );
};

export function ReviewsCarousel() {
  const carouselRef = useRef<HTMLDivElement>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = reviews.length;
  
  // Navegação pelos indicadores
  const scrollToIndex = (index: number) => {
    if (!carouselRef.current) return;
    
    const scrollAmount = carouselRef.current.scrollWidth * (index / totalSlides);
    carouselRef.current.scrollTo({
      left: scrollAmount,
      behavior: 'smooth'
    });
    
    setCurrentSlide(index);
  };
  
  // Efeito para atualizar indicador com base no scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!carouselRef.current) return;
      
      const { scrollLeft, scrollWidth, clientWidth } = carouselRef.current;
      const scrollProgress = scrollLeft / (scrollWidth - clientWidth);
      const slideIndex = Math.round(scrollProgress * (totalSlides - 1));
      
      if (slideIndex >= 0 && slideIndex !== currentSlide) {
        setCurrentSlide(slideIndex);
      }
    };
    
    const carouselElement = carouselRef.current;
    if (carouselElement) {
      carouselElement.addEventListener('scroll', handleScroll);
      return () => carouselElement.removeEventListener('scroll', handleScroll);
    }
  }, [currentSlide, totalSlides]);

  // Ajuste automático para mostrar os cards parcialmente
  useEffect(() => {
    const adjustCarouselPadding = () => {
      if (!carouselRef.current) return;
      
      // Calculando o padding para mostrar parte do próximo card
      const cardWidth = window.innerWidth < 640 ? 280 : 300;
      const viewportWidth = window.innerWidth;
      
      // Para mostrar 1.2 cards em mobile
      if (viewportWidth < 640) {
        const padding = (viewportWidth - cardWidth) / 2;
        carouselRef.current.style.paddingLeft = `${padding}px`;
        carouselRef.current.style.paddingRight = `${padding}px`;
      } 
      // Para mostrar 2.5 cards em tablet
      else if (viewportWidth < 1024) {
        const visibleCards = 2.5;
        const padding = (viewportWidth - (cardWidth * visibleCards)) / 2;
        carouselRef.current.style.paddingLeft = `${padding}px`;
        carouselRef.current.style.paddingRight = `${padding}px`;
      }
      // Para mostrar 3.5 cards em desktop
      else {
        const visibleCards = 3.5;
        const padding = (viewportWidth - (cardWidth * visibleCards)) / 2;
        carouselRef.current.style.paddingLeft = `${padding}px`;
        carouselRef.current.style.paddingRight = `${padding}px`;
      }
    };
    
    adjustCarouselPadding();
    window.addEventListener('resize', adjustCarouselPadding);
    
    return () => window.removeEventListener('resize', adjustCarouselPadding);
  }, []);
  
  return (
    <section className="px-4 py-4 bg-background" aria-labelledby="reviews-heading">
      <h2 id="reviews-heading" className="text-lg font-bold text-foreground mb-4 flex items-center">
        <span>⭐ Avaliações dos nossos clientes</span>
      </h2>
      
      <div className="flex items-center gap-4 mb-4 text-sm">
        <div className="flex items-center">
          <span className="text-yellow-400">⭐⭐⭐⭐⭐</span>
          <span className="ml-1 font-bold">5.0</span>
        </div>
        <span className="text-muted-foreground">+500 avaliações</span>
        <span className="text-green-600">✓ 98% recomendam</span>
      </div>
      
      <div 
        ref={carouselRef}
        className="flex overflow-x-auto gap-3 pb-4 no-scrollbar snap-x snap-mandatory"
        aria-label="Carrossel de avaliações de clientes"
      >
        {reviews.map((review) => (
          <div 
            key={review.id}
            className="snap-start flex-shrink-0 w-[280px] sm:w-[300px]"
          >
            <Card className="h-full overflow-hidden border border-border hover:shadow-md transition-smooth group p-4">
              <div className="flex items-center mb-3">
                {/* Foto do cliente */}
                <div className="w-12 h-12 rounded-full overflow-hidden mr-3 bg-muted">
                  <img 
                    src={review.image} 
                    alt={`Foto de ${review.name}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://burgzpedidos.com/images/avatar-placeholder.jpg";
                    }}
                    loading="lazy"
                  />
                </div>
                
                <div className="flex-grow">
                  {/* Nome do cliente */}
                  <h3 className="font-bold text-base text-foreground">
                    {review.name}
                  </h3>
                  
                  {/* Data da avaliação */}
                  <div className="text-xs text-muted-foreground">
                    {formatDate(review.date)}
                  </div>
                </div>
                
                {/* Rating */}
                <div className="flex flex-col items-end">
                  <RatingStars rating={review.rating} />
                  
                  {/* Badge de pedido verificado */}
                  {review.verified && (
                    <span className="bg-green-100 text-green-700 text-xs px-1.5 py-0.5 rounded-sm flex items-center mt-1">
                      <span className="mr-1" aria-hidden="true">✓</span> 
                      <span>Pedido Verificado</span>
                    </span>
                  )}
                </div>
              </div>
              
              {/* Comentário */}
              <p className="text-foreground text-sm leading-relaxed">
                {review.comment}
              </p>
            </Card>
          </div>
        ))}
      </div>
      
      {/* Indicadores de posição (dots) */}
      <div className="flex justify-center gap-1 mt-4" aria-hidden="true">
        {Array.from({ length: Math.min(8, totalSlides) }).map((_, i) => (
          <button
            key={i}
            className={`w-2 h-2 rounded-full transition-smooth ${
              i === currentSlide % 8 ? "bg-primary" : "bg-muted"
            }`}
            onClick={() => scrollToIndex(i)}
            aria-label={`Ir para avaliação ${i + 1}`}
          />
        ))}
      </div>
    </section>
  );
} 