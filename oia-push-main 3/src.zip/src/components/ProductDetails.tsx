import { X, Plus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CartItem } from "@/types/checkout";
import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence, PanInfo } from "framer-motion";
import { useScrollLock } from "@/hooks/useScrollLock";
import { debounce } from "lodash";
// Removendo a importação não utilizada
// import { OptimizedImage } from "./OptimizedImage";

interface ProductDetailsProps {
  product: {
    id: string;
    name: string;
    description: string;
    price: number;
    discountedPrice?: number;
    image: string;
    categoryId?: string;
    adicionais?: { name: string; price: number; }[];
    opcionais?: { name: string; price: number; }[];
  } | any; // Adicionando any para evitar erros de tipagem
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

export function ProductDetails({ product, onClose, onAddToCart }: ProductDetailsProps) {
  // Ativar scroll lock quando o modal estiver aberto
  useScrollLock(!!product);
  
  const [observacao, setObservacao] = useState("");
  const [selectedAdicionais, setSelectedAdicionais] = useState<{ name: string; price: number; }[]>([]);
  const [selectedOpcionais, setSelectedOpcionais] = useState<{ name: string; price: number; }[]>([]);
  const [finalPrice, setFinalPrice] = useState(0);
  
  // Lista de IDs de produtos que podem exibir adicionais e opcionais
  const productIdsWithAddonsAndOptions = new Set([
    "mp-1", "mp-2", "mp-3", "ef-1", "b-1", "b-2", "b-3", "b-4", "b-5", "b-6", "b-7", 
    "b-8", "b-9", "b-10", "b-11", "b-12", "b-13", "b-14", "b-15", "b-16", "b-17", "b-18"
  ]);

  // Verifica se o produto atual pode ter adicionais e opcionais
  const canHaveAddonsAndOptions = productIdsWithAddonsAndOptions.has(product.id);
  const isComboEspecial = product.categoryId === "combos-especiais";
  const canHaveObservations = canHaveAddonsAndOptions || isComboEspecial;
  
  const composition = [
    "Burguer",
    "Queijo Cheddar", 
    "Alface",
    "Tomate",
    "Cebola Roxa",
    "Maionese"
  ];

  // Calcula o preço base do produto (com ou sem desconto)
  const basePrice = product.discountedPrice || product.price;

  // Debounce para mudanças de preço
  const debouncedPriceUpdate = useMemo(
    () => debounce((newPrice: number) => {
      setFinalPrice(newPrice);
    }, 150),
    []
  );

  // Recalcula o preço final sempre que as seleções mudarem
  useEffect(() => {
    const adicionaisTotal = selectedAdicionais.reduce((total, item) => total + item.price, 0);
    const opcionaisTotal = selectedOpcionais.reduce((total, item) => total + item.price, 0);
    
    const newFinalPrice = basePrice + adicionaisTotal + opcionaisTotal;
    debouncedPriceUpdate(newFinalPrice);
  }, [basePrice, selectedAdicionais, selectedOpcionais, debouncedPriceUpdate]);

  // Função para alternar a seleção de um adicional
  const toggleAdicional = (adicional: { name: string; price: number }) => {
    setSelectedAdicionais(prev => {
      const isSelected = prev.some(item => item.name === adicional.name);
      
      if (isSelected) {
        return prev.filter(item => item.name !== adicional.name);
      } else {
        return [...prev, adicional];
      }
    });
  };

  // Função para alternar a seleção de um opcional
  const toggleOpcional = (opcional: { name: string; price: number }) => {
    setSelectedOpcionais(prev => {
      const isSelected = prev.some(item => item.name === opcional.name);
      
      if (isSelected) {
        return prev.filter(item => item.name !== opcional.name);
      } else {
        return [...prev, opcional];
      }
    });
  };

  // Verifica se um adicional está selecionado
  const isAdicionalSelected = (name: string) => {
    return selectedAdicionais.some(item => item.name === name);
  };

  // Verifica se um opcional está selecionado
  const isOpcionalSelected = (name: string) => {
    return selectedOpcionais.some(item => item.name === name);
  };

  // Função para adicionar ao carrinho com micro-animação
  const handleAddToCart = () => {
    const cartItem: CartItem = {
      id: product.id,
      name: product.name,
      unitPrice: basePrice,
      totalPrice: finalPrice * 1, // Multiplicado pela quantidade (que é sempre 1 neste caso)
      finalPrice: finalPrice,
      quantity: 1,
      addons: [], // Mantendo para compatibilidade
      image: product.image,
      observacao: observacao.trim() || undefined, // MANTER OBSERVAÇÕES PARA TODOS
      // Para produtos normais:
      selectedAdicionais: !isComboEspecial && selectedAdicionais.length > 0 ? selectedAdicionais : undefined,
      selectedOpcionais: !isComboEspecial && selectedOpcionais.length > 0 ? selectedOpcionais : undefined
    };
    
    onAddToCart(cartItem);
  };

  // Verifica se é um hambúrguer (categoria burgers ou mais-pedidos)
  const isBurger = product.categoryId === "burgers" || product.categoryId === "mais-pedidos";

  return (
    <AnimatePresence>
      {product && (
        <motion.div 
          className="fixed inset-0 z-50 flex items-end bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <motion.div 
            className="w-full bg-background rounded-t-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ 
              type: "spring", 
              stiffness: 300, 
              damping: 30,
              duration: 0.3 
            }}
            onClick={(e) => e.stopPropagation()}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.2 }}
            onDragEnd={(event, info: PanInfo) => {
              // Fechar se arrastar mais de 150px para baixo
              if (info.offset.y > 150) {
                onClose();
              }
            }}
          >
            {/* Indicador visual de drag */}
            <motion.div 
              className="w-12 h-1 bg-gray-300 rounded-full mx-auto mt-2 mb-2"
              initial={{ opacity: 0, scaleX: 0.5 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ delay: 0.2 }}
            />

            {/* Header com imagem do produto */}
            <motion.div 
              className="relative h-48 bg-cover bg-center rounded-t-2xl"
              style={{ backgroundImage: `url(${product.image})` }}
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.4 }}
            >
              <div className="absolute inset-0 bg-black/40 rounded-t-2xl" />
              
              {/* Botão fechar com animação */}
              <motion.button
                onClick={onClose}
                className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 shadow-lg"
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <X className="h-5 w-5" />
              </motion.button>
              
              {/* Badge do produto com animação */}
              <motion.div 
                className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg px-3 py-1"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2, duration: 0.3 }}
              >
                <span className="font-bold text-sm text-foreground">{product.name}</span>
              </motion.div>
            </motion.div>

            {/* Conteúdo com animação escalonada */}
            <motion.div 
              className="p-4 max-h-[60vh] overflow-y-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1, duration: 0.3 }}
            >
              {/* Preço */}
              <motion.div 
                className="mb-6"
                layout
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
              >
                <span className="text-xs text-muted-foreground">PREÇO FINAL</span>
                <motion.div 
                  className="flex items-center gap-2 flex-wrap"
                  key={finalPrice} // Re-animar quando preço mudar
                  initial={{ scale: 1.1, color: "#10b981" }}
                  animate={{ scale: 1, color: "#10b981" }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <div className="text-2xl font-bold text-green-500">
                    R$ {finalPrice.toFixed(2).replace('.', ',')}
                  </div>
                  {product.price && product.discountedPrice && (
                    <div className="text-lg text-red-500 line-through font-medium">
                      R$ {product.price.toFixed(2).replace('.', ',')}
                    </div>
                  )}
                </motion.div>
                {(selectedAdicionais.length > 0 || selectedOpcionais.length > 0) && (
                  <div className="text-xs text-muted-foreground mt-1">
                    Preço base + {selectedAdicionais.length + selectedOpcionais.length} itens selecionados
                  </div>
                )}
              </motion.div>

              {/* Description */}
              <motion.p 
                className="text-sm text-muted-foreground mb-6 leading-relaxed"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                {product.description}
              </motion.p>

              {/* Para COMBOS ESPECIAIS - mostrar APENAS observações */}
              {isComboEspecial && (
                <motion.div 
                  className="mb-6"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <div className="mb-4 bg-blue-500 text-white px-4 py-2 rounded-full text-sm font-bold inline-block">
                    Observações do Combo
                  </div>
                  <textarea
                    className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Ex: Sem cebola nos hambúrgueres, ponto da carne, trocar refrigerante, etc."
                    rows={3}
                    value={observacao}
                    onChange={(e) => setObservacao(e.target.value)}
                  />
                </motion.div>
              )}

              {/* Para PRODUTOS NORMAIS - mostrar composição + adicionais + opcionais + observações */}
              {canHaveAddonsAndOptions && !isComboEspecial && (
                <>
                  {/* Composition - apenas para burgers */}
                  {isBurger && (
                    <motion.div 
                      className="mb-6"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.25 }}
                    >
                      <Button 
                        variant="default" 
                        className="mb-4 bg-primary text-primary-foreground font-medium rounded-full px-6"
                      >
                        Composição
                      </Button>
                      <div className="space-y-3">
                        {composition.map((item, index) => (
                          <motion.div 
                            key={index} 
                            className="text-sm text-foreground"
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.3 + index * 0.05 }}
                          >
                            {item}
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Adicionais */}
                  {product.adicionais && product.adicionais.length > 0 && (
                    <motion.div 
                      className="mb-6"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.35 }}
                    >
                      <div className="mb-4 bg-yellow-400 text-black px-4 py-2 rounded-full text-sm font-bold inline-block">
                        Deseja Adicionais?
                      </div>
                      <div className="space-y-3">
                        {product.adicionais.map((item, index) => {
                          const isSelected = isAdicionalSelected(item.name);
                          return (
                            <div key={index} className="flex items-center justify-between py-2 border-b border-gray-200 last:border-b-0">
                              <span className="text-sm text-foreground">{item.name}</span>
                              <motion.button
                                onClick={() => toggleAdicional(item)}
                                className={`rounded-full px-4 py-1 ${
                                  isSelected 
                                    ? "bg-primary text-primary-foreground" 
                                    : "border border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                                }`}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                layout
                                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                              >
                                {isSelected ? (
                                  <motion.span 
                                    className="flex items-center"
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                  >
                                    <Check className="h-4 w-4 mr-1" /> Selecionado
                                  </motion.span>
                                ) : (
                                  `+ R$ ${item.price.toFixed(2).replace('.', ',')}`
                                )}
                              </motion.button>
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}

                  {/* Opcionais */}
                  {product.opcionais && product.opcionais.length > 0 && (
                    <motion.div 
                      className="mb-6"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.45 }}
                    >
                      <div className="mb-4 bg-yellow-400 text-black px-4 py-2 rounded-full text-sm font-bold inline-block">
                        Opcionais
                      </div>
                      <div className="space-y-3">
                        {product.opcionais.map((item, index) => {
                          const isSelected = isOpcionalSelected(item.name);
                          return (
                            <div key={index} className="flex items-center justify-between py-2 border-b border-gray-200 last:border-b-0">
                              <span className="text-sm text-foreground">{item.name}</span>
                              <motion.button
                                onClick={() => toggleOpcional(item)}
                                className={`rounded-full px-4 py-1 ${
                                  isSelected 
                                    ? "bg-primary text-primary-foreground" 
                                    : "border border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                                }`}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                layout
                                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                              >
                                {isSelected ? (
                                  <motion.span 
                                    className="flex items-center"
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                  >
                                    <Check className="h-4 w-4 mr-1" /> Selecionado
                                  </motion.span>
                                ) : (
                                  `+ R$ ${item.price.toFixed(2).replace('.', ',')}`
                                )}
                              </motion.button>
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}

                  {/* Observações */}
                  <motion.div 
                    className="mb-6"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.55 }}
                  >
                    <div className="mb-4 bg-blue-500 text-white px-4 py-2 rounded-full text-sm font-bold inline-block">
                      Observações
                    </div>
                    <textarea
                      className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="Ex: Sem cebola, sem tomate, ponto da carne, etc."
                      rows={3}
                      value={observacao}
                      onChange={(e) => setObservacao(e.target.value)}
                    />
                  </motion.div>
                </>
              )}

              {/* Add to cart button */}
              <div className="sticky bottom-0 bg-background pt-4 pb-2">
                <motion.button
                  onClick={handleAddToCart}
                  className="w-full bg-primary hover:bg-primary-hover text-primary-foreground font-medium py-3 rounded-lg"
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.1 }}
                  >
                    Adicionar ao Pedido
                  </motion.span>
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}