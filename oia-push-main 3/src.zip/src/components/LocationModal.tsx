'use client';

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Tipos
type LocationStep = 
  | 'loading-initial'
  | 'select-state'
  | 'select-city'
  | 'loading-store'
  | 'results';

type LocationInfo = {
  state: string;
  city: string;
  storeDistance?: string;
  deliveryTime?: string;
};

interface LocationModalProps {
  onLocationConfirmed: () => void;
}

// Lista mock de estados
const STATES = [
  'São Paulo',
  'Rio de Janeiro',
  'Minas Gerais',
  'Paraná',
  'Santa Catarina',
  'Rio Grande do Sul',
];

// Lista mock de cidades por estado
const CITIES: Record<string, string[]> = {
  'São Paulo': ['São Paulo', 'Campinas', 'Guarulhos', 'Santos', 'São José dos Campos'],
  'Rio de Janeiro': ['Rio de Janeiro', 'Niterói', 'Petrópolis', 'Angra dos Reis'],
  'Minas Gerais': ['Belo Horizonte', 'Uberlândia', 'Juiz de Fora', 'Ouro Preto'],
  'Paraná': ['Curitiba', 'Londrina', 'Maringá', 'Foz do Iguaçu'],
  'Santa Catarina': ['Florianópolis', 'Joinville', 'Blumenau', 'Balneário Camboriú'],
  'Rio Grande do Sul': ['Porto Alegre', 'Gramado', 'Caxias do Sul', 'Pelotas'],
};

const LOCATION_STORAGE_KEY = 'oia_burguer_user_location';

export const LocationModal = ({ onLocationConfirmed }: LocationModalProps) => {
  console.log('LocationModal renderizado');
  
  const navigate = useNavigate();
  const [step, setStep] = useState<LocationStep>('loading-initial');
  const [locationInfo, setLocationInfo] = useState<LocationInfo>({
    state: 'São Paulo',
    city: 'São Paulo',
    storeDistance: '4,5km',
    deliveryTime: '30 a 50 minutos'
  });
  
  console.log('LocationModal montado', { step });
  
  // Iniciar detecção de localização ao montar o componente
  useEffect(() => {
    console.log('LocationModal useEffect - iniciando detecção');
    
    // Simular detecção automática após um breve delay
    setTimeout(() => {
      // Simular que detectamos São Paulo
      setLocationInfo(prev => ({
        ...prev,
        state: 'São Paulo',
        city: 'São Paulo'
      }));
      
      // Avançar para o carregamento da loja
      simulateStoreLoading();
    }, 2000);
  }, []);
  
  // Simular carregamento de loja próxima
  const simulateStoreLoading = () => {
    setStep('loading-store');
    console.log('Simulando carregamento da loja');
    
    // Simular um tempo de carregamento
    setTimeout(() => {
      const updatedLocationInfo = {
        ...locationInfo,
        storeDistance: '4,5km',
        deliveryTime: '30 a 50 minutos'
      };
      
      // Atualizar o estado
      setLocationInfo(updatedLocationInfo);
      
      // Salvar no localStorage
      localStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify({
        city: updatedLocationInfo.city,
        state: updatedLocationInfo.state,
        timestamp: Date.now()
      }));
      
      console.log('Loja encontrada, mostrando resultados');
      // Mostrar os resultados
      setStep('results');
    }, 2000);
  };
  
  // Lidar com mudança de estado
  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newState = e.target.value;
    setLocationInfo(prev => ({
      ...prev,
      state: newState,
      // Resetar cidade ao mudar estado
      city: CITIES[newState]?.[0] || ''
    }));
  };
  
  // Lidar com mudança de cidade
  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCity = e.target.value;
    setLocationInfo(prev => ({
      ...prev,
      city: newCity
    }));
  };
  
  // Avançar para seleção de cidade
  const goToSelectCity = () => {
    setStep('select-city');
  };
  
  // Iniciar busca de loja
  const startStoreSearch = () => {
    simulateStoreLoading();
  };
  
  // Finalizar fluxo e fechar modal
  const finishLocationFlow = () => {
    // Fechar o modal e mostrar o cardápio
    onLocationConfirmed();
    
    // Adicionar uma classe para animar a aparição do cardápio
    const menuElement = document.querySelector('main');
    if (menuElement) {
      menuElement.classList.add('animate-fade-in');
      
      // Rolar suavemente para o início do cardápio
      setTimeout(() => {
        const featuredSection = document.querySelector('.pb-4.pt-3');
        if (featuredSection) {
          featuredSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 300);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-md p-6 shadow-lg transform transition-all duration-300 ease-in-out">
        {/* Carregamento Inicial */}
        {step === 'loading-initial' && (
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Procurando a loja mais próxima...</h2>
            <p className="mb-6">Procurando a loja mais próxima de você...</p>
            <div className="flex justify-center mb-4">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
            </div>
          </div>
        )}
        
        {/* Seleção de Estado */}
        {step === 'select-state' && (
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Procure a loja mais próxima de você!</h2>
            <p className="mb-4">Escolha seu estado:</p>
            <select 
              className="w-full p-3 border border-gray-300 rounded-lg mb-6 focus:outline-none focus:ring-2 focus:ring-green-500"
              value={locationInfo.state}
              onChange={handleStateChange}
            >
              {STATES.map(state => (
                <option key={state} value={state}>{state}</option>
              ))}
            </select>
            <button
              onClick={goToSelectCity}
              className="w-full py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors duration-200"
            >
              Próximo
            </button>
          </div>
        )}
        
        {/* Seleção de Cidade */}
        {step === 'select-city' && (
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Estamos quase lá...</h2>
            <p className="mb-4">Agora, selecione sua cidade:</p>
            <select 
              className="w-full p-3 border border-gray-300 rounded-lg mb-6 focus:outline-none focus:ring-2 focus:ring-green-500"
              value={locationInfo.city}
              onChange={handleCityChange}
            >
              {CITIES[locationInfo.state]?.map(city => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
            <button
              onClick={startStoreSearch}
              className="w-full py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors duration-200"
            >
              Procurar loja mais próxima!
            </button>
          </div>
        )}
        
        {/* Carregamento da Loja */}
        {step === 'loading-store' && (
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Procurando a loja mais próxima...</h2>
            <p className="mb-6">Procurando a loja mais próxima de você em {locationInfo.city}...</p>
            <div className="flex justify-center mb-4">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
            </div>
          </div>
        )}
        
        {/* Resultados */}
        {step === 'results' && (
          <div className="text-center">
            <h2 className="text-xl font-bold mb-4">Loja Encontrada!</h2>
            <div className="flex justify-center mb-6">
              <div className="bg-green-100 p-4 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <p className="text-lg mb-6">
              A loja mais próxima fica a {locationInfo.storeDistance} de você! Seu pedido chegará entre {locationInfo.deliveryTime}.
            </p>
            <button
              onClick={finishLocationFlow}
              className="w-full py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors duration-200"
            >
              Olhar cardápio de ofertas!
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationModal; 