import { FC } from 'react';
import { motion } from 'framer-motion';
import { Truck, Clock, Loader2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { AddressData, DeliveryInfo } from '@/services/locationService';

interface AddressConfirmationProps {
  address: AddressData;
  deliveryInfo: DeliveryInfo;
  onConfirm: () => void;
  onEdit: () => void;
  isLoading: boolean;
}

export const AddressConfirmation: FC<AddressConfirmationProps> = ({
  address,
  deliveryInfo,
  onConfirm,
  onEdit,
  isLoading
}) => {
  const formatAddress = (address: AddressData): string => {
    let formatted = `${address.rua}, ${address.numero}, ${address.bairro}, ${address.cidade} - ${address.estado}, ${address.cep}`;
    return formatted;
  };

  return (
    <motion.div 
      className="p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      {/* Título */}
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Confirme sua localização:
      </h3>

      {/* Card do endereço - EXATO como food24horas */}
      <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded-r-lg mb-6">
        <p className="text-green-800 font-medium leading-relaxed">
          📍 {formatAddress(address)}
        </p>
      </div>

      {/* Informações de entrega - LAYOUT FOOD24HORAS */}
      <div className="space-y-3 mb-6">
        {/* Taxa de entrega */}
        <div className="flex items-center">
          <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3">
            <Truck className="w-4 h-4 text-orange-600" />
          </div>
          <span className="text-gray-900">
            <strong>Entrega grátis</strong>
          </span>
        </div>

        {/* Tempo estimado */}
        <div className="flex items-center">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <span className="text-gray-900">
            <strong>Tempo estimado: 20-40 min</strong>
          </span>
        </div>
      </div>

      {/* Botões - EXATO como food24horas */}
      <div className="space-y-3 pt-4">
        {/* Botão Editar - outline */}
        <Button 
          onClick={onEdit} 
          variant="outline" 
          className="w-full h-12 border-2 border-gray-900 text-gray-900 font-semibold hover:bg-gray-50"
          disabled={isLoading}
        >
          Editar
        </Button>
        
        {/* Botão Acessar Cardápio - preto */}
        <Button 
          onClick={onConfirm} 
          className="w-full h-12 bg-orange-500 text-white font-semibold hover:bg-orange-600 flex items-center justify-center"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Processando...
            </>
          ) : 'Acessar Cardápio'}
        </Button>
      </div>
    </motion.div>
  );
}; 