import Menu from "./Menu";

const Index = () => {
  return <Menu />;
};

export default Index;
