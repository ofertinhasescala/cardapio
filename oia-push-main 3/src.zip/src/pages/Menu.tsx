import { useState, useEffect, useRef } from "react";
import { Header } from "@/components/Header";
import { CategoryNav } from "@/components/CategoryNav";
import { ProductCard } from "@/components/ProductCard";
import { ProductDetails } from "@/components/ProductDetails";
import { CartItem } from "@/types/checkout";
import { FeaturedCarousel } from "@/components/FeaturedCarousel";
import { ReviewsSection } from "@/components/ReviewsSection";
import { MenuSkeleton } from "@/components/MenuSkeleton";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/hooks/useCart";
import { ModernLocationModal } from "@/components/ModernLocationModal"; // Importação atualizada
import { ComboSpecialCard } from "@/components/ComboSpecialCard";
import { useDynamicDay } from "@/hooks/useDynamicDay";
import { generateDynamicBadges, getTimeBasedUrgency } from "@/utils/dynamicBadges";
import { AddressData } from "@/services/locationService"; // Adicionar esta importação

// Imports das imagens
import oiaBaconImg from "@/assets/oia-bacon.jpg";
import oiaClassicImg from "@/assets/oia-classic.jpg";
import orangeSodaImg from "@/assets/orange-soda.jpg";
import chocolateBrownieImg from "@/assets/chocolate-brownie.jpg";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  discountedPrice?: number;
  image: string;
  categoryId: string;
  featured?: boolean;
  adicionais?: { name: string; price: number; }[];
  opcionais?: { name: string; price: number; }[];
  badge?: string;
  specialStyle?: boolean;
  badgeColor?: string;
  socialProof?: string;
  scarcity?: string;
  urgency?: string;
}

interface Category {
  id: string;
  name: string;
}

// Atualização das categorias com combos-especiais em primeiro lugar
const categories: Category[] = [
  { id: "combos-especiais", name: "🔥 COMBOS ESPECIAIS" },
  { id: "burgers", name: "Burguer" },
  { id: "porcoes", name: "Porções" },
  { id: "bebidas", name: "Bebidas" },
  { id: "cervejas", name: "Cervejas Long Neck" },
];

// Função para converter preço de string para número
const parsePrice = (priceStr: string) => {
  return parseFloat(priceStr.replace(',', '.'));
};

// Função para calcular o preço com desconto de 40%
const calculateDiscountedPrice = (price: number) => {
  return parseFloat((price * 0.6).toFixed(2));
};

// Função para selecionar imagem com base no nome do produto
const selectImage = (name: string) => {
  if (name.toLowerCase().includes('bacon') || name.toLowerCase().includes('costela') || 
      name.toLowerCase().includes('burguer') || name.toLowerCase().includes('braza')) {
    return oiaBaconImg;
  } else if (name.toLowerCase().includes('fritas') || name.toLowerCase().includes('batata') ||
            name.toLowerCase().includes('coxinha') || name.toLowerCase().includes('onion')) {
    return orangeSodaImg;
  } else if (name.toLowerCase().includes('brownie') || name.toLowerCase().includes('docin')) {
    return chocolateBrownieImg;
  } else {
    return orangeSodaImg; // Imagem padrão para bebidas e outros
  }
};

// Dados dos combos especiais - array vazio, será preenchido dinamicamente
const combosEspeciais: Product[] = [];

// Produtos existentes (mantendo apenas os produtos que não são combos especiais)
const products: Product[] = [
  // Os Mais Pedidos
  {
    id: "mp1",
    name: "Braza Roça Burguer",
    description: "160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar Vigor Tostado No Maçarico, Tomate Saladete, Alface Americana, Cebola Roxa em Rodelas, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("31,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("31,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_3.jpg", // URL da imagem
    categoryId: "mais-pedidos",
    featured: true,
    adicionais: [
      { name: "Adicione Fritas e Refri 350ml", price: 23.99 },
      { name: "Burguer 180g", price: 13.99 },
      { name: "Bacon Extra", price: 6.99 }
    ],
    opcionais: [
      { name: "Pão de Brioche", price: 2.75 },
      { name: "Pão de Gergelim Branco", price: 2.75 },
      { name: "Queijo Mussarela", price: 4.99 },
      { name: "Queijo Prato", price: 4.99 },
      { name: "Queijo Cheddar", price: 4.99 }
    ]
  },
  {
    id: "mp2",
    name: "Costela Burguer",
    description: "200g de Costela Suculenta Preparada Na Brasa (parrilla), Recheado com Uma Explosão de Cheddar Cremoso e Uma Camada Extra de Queijo Prato, Coleslaw (salada de Repolho), Bacon em Tiras, Maionese da Braza e Pão com Gergelim Selado No Fogo",
    price: parsePrice("41,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("41,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_16.jpg", // URL da imagem
    categoryId: "mais-pedidos",
    featured: true,
    adicionais: [
      { name: "Adicione Fritas e Refri 350ml", price: 23.99 },
      { name: "Costela Extra 100g", price: 15.99 },
      { name: "Bacon Extra", price: 6.99 }
    ],
    opcionais: [
      { name: "Pão de Brioche", price: 2.75 },
      { name: "Pão de Gergelim Branco", price: 2.75 },
      { name: "Queijo Mussarela", price: 4.99 },
      { name: "Queijo Prato", price: 4.99 },
      { name: "Queijo Cheddar", price: 4.99 }
    ]
  },
  {
    id: "mp3",
    name: "Furioso Burguer",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Mussarela Tostado No Maçarico, Cebola Caramelizada, Bacon em Tiras, Cebola Crispy, Barbecue Defumado, Alface Americana, Maionese da Braza e Pão Australiano Selado No Fogo",
    price: parsePrice("43,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("43,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_17.png", // URL da imagem
    categoryId: "mais-pedidos",
    featured: true,
    adicionais: [
      { name: "Adicione Fritas e Refri 350ml", price: 23.99 },
      { name: "Burguer 180g", price: 13.99 },
      { name: "Bacon Extra", price: 6.99 }
    ],
    opcionais: [
      { name: "Pão de Brioche", price: 2.75 },
      { name: "Pão Australiano", price: 3.50 },
      { name: "Pão de Gergelim Branco", price: 2.75 },
      { name: "Queijo Mussarela", price: 4.99 },
      { name: "Queijo Prato", price: 4.99 },
      { name: "Queijo Cheddar", price: 4.99 }
    ]
  },
  {
    id: "mp4",
    name: "Fritas com Bacon e Cheddar",
    description: "200g de Fritas Tradicional Mccain Crocante Por Fora e Macia Por Dentro, 100g de Bacon Crocante em Cubinhos e Cheddar Cremoso Vigor",
    price: parsePrice("38,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("38,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_37.jpg", // URL da imagem
    categoryId: "mais-pedidos",
    featured: true
  },
  {
    id: "mp5",
    name: "Coxinhas de Frango com Requeijão",
    description: "8 Un de Coxinhas Deliciosas de Frango com Requeijão",
    price: parsePrice("29,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("29,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_41.jpg", // URL da imagem
    categoryId: "mais-pedidos"
  },

  // Especial Férias de Julho
  {
    id: "ef1",
    name: "O Brabo",
    description: "Burguer Suculento 160g Feito Na Parrilla (brasa), Queijo Mussarela Tostado No Maçarico, Bacon em Tiras, Catupiry Empanado Crocante Por Fora, Cremoso e Saboroso Por Dentro, Maionese de Chimichurri e Pão de Brioche Selado No Fogo",
    price: parsePrice("42,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("42,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_49.JPG", // URL da imagem
    categoryId: "especiais",
    featured: true
  },
  {
    id: "ef2",
    name: "Docin da Braza",
    description: "Uma Sobremesa Feita com Carinho: Creme de Ninho, Moranguinho Fresco, Geleia Caseira de Framboesa e Suspiro Quebradinho. Camadas de Afeto em Cada Colherada.",
    price: parsePrice("19,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("19,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_50.JPG", // URL da imagem
    categoryId: "especiais"
  },

  // Burgers
  {
    id: "b1",
    name: "Braza Bacon",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Mussarela Tostado No Maçarico, + Bacon em Tiras, Cebola Caramelizada, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("35,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("35,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_1.jpg", // URL da imagem
    categoryId: "burgers",
    adicionais: [
      { name: "Adicione Fritas e Refri 350ml", price: 23.99 },
      { name: "Burguer 180g", price: 13.99 },
      { name: "Bacon Extra", price: 6.99 }
    ],
    opcionais: [
      { name: "Pão de Brioche", price: 2.75 },
      { name: "Pão de Gergelim Branco", price: 2.75 },
      { name: "Queijo Mussarela", price: 4.99 },
      { name: "Queijo Prato", price: 4.99 },
      { name: "Queijo Cheddar", price: 4.99 }
    ]
  },
  {
    id: "b2",
    name: "Braza 237",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Triplo Queijo Cheddar Tostado No Maçarico, Farofa de Bacon, Alface Americana, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("31,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("31,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_2.JPG", // URL da imagem
    categoryId: "burgers",
    adicionais: [
      { name: "Adicione Fritas e Refri 350ml", price: 23.99 },
      { name: "Burguer 180g", price: 13.99 },
      { name: "Bacon Extra", price: 6.99 }
    ],
    opcionais: [
      { name: "Pão de Brioche", price: 2.75 },
      { name: "Pão de Gergelim Branco", price: 2.75 },
      { name: "Queijo Mussarela", price: 4.99 },
      { name: "Queijo Prato", price: 4.99 },
      { name: "Queijo Cheddar", price: 4.99 }
    ]
  },
  {
    id: "b3",
    name: "Braza Roça",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar Vigor Tostado No Maçarico, Tomate Saladete, Alface Americana, Cebola Roxa em Rodelas, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("31,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("31,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_3.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b4",
    name: "Braza Burguer",
    description: "Burguer Suculento 160g Feito Na Parrilla (brasa), Queijo Mussarela Tostado No Maçarico, Bacon em Tiras, Alface Americana, Geleia de Pimenta Gourmet (suave), Maionese da Braza e Pão com Gergelim Selado No Fogo",
    price: parsePrice("36,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("36,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_4.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b5",
    name: "Braza Trovão",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar Tostado No Maçarico, Bacon em Tiras, Alface Americana, Picles Agridoce, Cebola Crispy, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("37,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("37,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_5.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b6",
    name: "King Crispy",
    description: "Filé de Frango em Tiras Empanadas, Queijo Mussarela Tostado No Maçarico, Bacon em Tiras, Alface Americana, Tomate Saladete, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("34,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("34,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_6.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b7",
    name: "Sr Cheddar",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Picles Agridoce, Bacon em Tiras, Cebola Roxa em Rodelas, American Cheese (cheddar Cremoso), Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("39,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("39,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_7.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b8",
    name: "Braza Fogo",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Mussarela Tostado No Maçarico, Cebola Roxa em Rodelas, Alface Americana, Molho Jack Barbecue Defumado, Maionese da Braza e Pão com Gergelim Selado No Fogo",
    price: parsePrice("32,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("32,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_8.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b9",
    name: "Braza Monster",
    description: "2 Burguer 160g Suculentos Feito Na Brasa (parrilla), 4 Fatias de Queijo Muçarela Tostado No Maçarico, + Bacon em Tiras, Molho Jack Barbecue Defumado e Mayo da Casa, Maionese da Braza e Pão com Gergelim Selado No Fogo",
    price: parsePrice("51,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("51,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_8.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b10",
    name: "Braza Vegetariano",
    description: "Burguer Fazenda do Futuro 115g, Queijo Mussarela Tostado No Maçarico, Alface America, Tomate Saladete, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("34,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("34,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_10.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b11",
    name: "Braza Classic",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar Tostado No Maçarico, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("27,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("27,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_11.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b12",
    name: "Braza Kids",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar Tostado No Maçarico, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("24,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("24,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_12.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b13",
    name: "Pampa Burguer",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Alface Americana, Bacon em Tiras, 100g Queijo Mussarela Empanado, Mostarda Honey (mostarda/ Mel), Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("45,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("45,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_13.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b14",
    name: "Onion Burguer",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Alface Americana, Cebola Roxa em Rodelas, Queijo Cheddar, Bacon em Tiras, Anéis de Cebola, Barbecue Defumado, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("44,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("44,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_14.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b15",
    name: "Chimiburguer",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Prato Tostado No Maçarico, Chimichurri Gourmet (picante), Bacon em Tiras, Alface Americana, Cebola Roxa em Rodelas, Maionese da Braza com Chimichurri e Pão de Brioche Selado No Fogo",
    price: parsePrice("37,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("37,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_15.JPEG", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b16",
    name: "Costela Burguer",
    description: "200g de Costela Suculenta Preparada Na Brasa (parrilla), Recheado com Uma Explosão de Cheddar Cremoso e Uma Camada Extra de Queijo Prato, Coleslaw (salada de Repolho), Bacon em Tiras, Maionese da Braza e Pão com Gergelim Selado No Fogo",
    price: parsePrice("41,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("41,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_16.jpg", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b17",
    name: "Furioso Burguer",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Mussarela Tostado No Maçarico, Cebola Caramelizada, Bacon em Tiras, Cebola Crispy, Barbecue Defumado, Alface Americana, Maionese da Braza e Pão Australiano Selado No Fogo",
    price: parsePrice("43,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("43,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_17.png", // URL da imagem
    categoryId: "burgers"
  },
  {
    id: "b18",
    name: "Mister Cheddar",
    description: "Burguer 160g Suculento Feito Na Brasa (parrilla), Queijo Cheddar, Cortado ao Meio e Mergulhado No American Cheese (piscininha de Cheddar), Bacon Picadinho, Maionese da Braza e Pão de Brioche Selado No Fogo",
    price: parsePrice("45,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("45,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_18.png", // URL da imagem
    categoryId: "burgers"
  },

  // Porções
  {
    id: "p1",
    name: "Batata Tradicional",
    description: "Batata Frita Mccain 120g Cracante Por Fora e Macia Por Dentro",
    price: parsePrice("18,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("18,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_19.jpg", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p2",
    name: "Batata Rústica",
    description: "Batata Rústica 120g Levemente Crocante Por Fora e Macia Por Dentro",
    price: parsePrice("18,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("18,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_36.png", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p3",
    name: "Fritas com Bacon e Cheddar",
    description: "200g de Fritas Tradicional Mccain Crocante Por Fora e Macia Por Dentro, 100g de Bacon Crocante em Cubinhos e Cheddar Cremoso Vigor",
    price: parsePrice("38,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("38,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_37.jpg", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p4",
    name: "Onion Rings (mccain)",
    description: "8 Um Anéis de Cebola Mccain Empanados",
    price: parsePrice("18,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("18,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_39.jpg", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p5",
    name: "Almofadinha de Queijo Gouda",
    description: "8 Un de Almofadinhas de Queijo Gouda Empanadas",
    price: parsePrice("29,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("29,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_40.png", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p6",
    name: "Coxinhas de Frango com Requeijão",
    description: "8 Un de Coxinhas Deliciosas de Frango com Requeijão",
    price: parsePrice("29,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("29,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_41.jpg", // URL da imagem
    categoryId: "porcoes"
  },
  {
    id: "p7",
    name: "Nuggets de Frango com Bacon",
    description: "8 Un de Nuggets Supreme Seara, Levemente Crocante Por Fora e Macio Por Dentro",
    price: parsePrice("29,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("29,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_42.png", // URL da imagem
    categoryId: "porcoes"
  },

  // Bebidas
  {
    id: "d1",
    name: "Água sem Gás",
    description: "Água sem Gás",
    price: parsePrice("5,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("5,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_33.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d2",
    name: "Água com Gás",
    description: "Água com Gás",
    price: parsePrice("5,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("5,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_34.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d3",
    name: "Coca Cola 350ml",
    description: "Coca Cola 350ml",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_20.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d4",
    name: "Coca Cola Zero 350ml",
    description: "Coca Cola 350ml Zero",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_21.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d5",
    name: "Fanta Laranja 350ml",
    description: "Fanta Laranja 350ml",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_26.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d6",
    name: "Sprite 350ml",
    description: "Sprite 350ml",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_24.png", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d7",
    name: "Guaraná Antarctica 350ml",
    description: "Guaraná Antarctica 350ml",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_22.jpg", // URL da imagem
    categoryId: "bebidas"
  },
  {
    id: "d8",
    name: "Tonica Antarctica 350ml",
    description: "Tonica Antarctica 350ml",
    price: parsePrice("6,00"),
    discountedPrice: calculateDiscountedPrice(parsePrice("6,00")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_38.png", // URL da imagem
    categoryId: "bebidas"
  },

  // Cervejas Long Neck
  {
    id: "c1",
    name: "Corona Extra 330ml",
    description: "Corona Extra 330ml",
    price: parsePrice("12,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("12,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_29.png", // URL da imagem
    categoryId: "cervejas"
  },
  {
    id: "c2",
    name: "Colorado Larger 355ml",
    description: "Colorado Larger 355ml",
    price: parsePrice("12,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("12,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_30.png", // URL da imagem
    categoryId: "cervejas"
  },
  {
    id: "c3",
    name: "Heineken 330ml",
    description: "Heineken 330ml",
    price: parsePrice("11,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("11,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_28.png", // URL da imagem
    categoryId: "cervejas"
  },
  {
    id: "c4",
    name: "Sol 330ml",
    description: "Sol 330ml",
    price: parsePrice("9,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("9,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_31.png", // URL da imagem
    categoryId: "cervejas"
  },
  {
    id: "c5",
    name: "Corona Extra Zero 330ml",
    description: "Corona Extra 330ml",
    price: parsePrice("12,99"),
    discountedPrice: calculateDiscountedPrice(parsePrice("12,99")),
    image: "https://servidor2.livn.com.br/image/oiaburguerfb_29.png", // URL da imagem
    categoryId: "cervejas"
  }
];

export default function Menu() {
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("combos-especiais"); // Definir combos-especiais como categoria inicial
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showMenu, setShowMenu] = useState(false); // Estado para controlar a visibilidade do cardápio
  const [userAddress, setUserAddress] = useState<AddressData | null>(null); // Novo estado para armazenar endereço
  const { toast } = useToast();
  const { addToCart } = useCart();
  const categoryRefs = useRef<Record<string, HTMLDivElement | null>>({});
  
  // Hook para dia da semana dinâmico
  const dayInfo = useDynamicDay();
  const dynamicBadges = generateDynamicBadges(dayInfo);
  const timeUrgency = getTimeBasedUrgency();
  
  // Combos especiais com badges dinâmicos
  const dynamicCombosEspeciais: Product[] = [
    {
      id: "combo1",
      name: "2x Combo Burgz Crispy Bacon em DOBRO + 2x Coca-Cola + 2x Fritas",
      description: "2x Combo Burgz Crispy Bacon em DOBRO + 2x Coca-Cola + 2x Fritas. Pão de hambúrguer, 3x Hambúrguer artesanal 120g, Cebola Crispy, Cheddar, Barbecue, Alface, Tomate e molho da casa.",
      price: 79.90,
      discountedPrice: 32.90,
      image: "https://ik.imagekit.io/gv9zqjxfk/ChatGPT%20Image%2013%20de%20jul.%20de%202025,%2002_20_14.png?updatedAt=1752420674084",
      categoryId: "combos-especiais",
      featured: true,
      badge: dynamicBadges.combo1.badge,
      urgency: dynamicBadges.combo1.urgency,
      specialStyle: true,
      badgeColor: "red"
    },
    {
      id: "combo2", 
      name: "Combo Família 5 Lanches + Bebida + Fritas",
      description: "2x Classic Costela, 2x Classic Salada, 1x Classic Melt. Todos lanches acompanham bebida e fritas!",
      price: 129.90,
      discountedPrice: 57.90,
      image: "https://ik.imagekit.io/gv9zqjxfk/ChatGPT%20Image%2013%20de%20jul.%20de%202025,%2002_09_11.png?updatedAt=1752420906212",
      categoryId: "combos-especiais",
      featured: true,
      badge: dynamicBadges.combo2.badge,
      urgency: dynamicBadges.combo2.urgency,
      socialProof: dynamicBadges.combo2.socialProof,
      specialStyle: true,
      badgeColor: "red",
      scarcity: "Apenas 2 combo(s) com esse preço especial!"
    },
    {
      id: "combo3",
      name: "RODÍZIO EM CASA - 6x Hambúrgueres + 500g de Fritas + 500g Nuggets + 2x Coca-Cola 2 Litros + 4 Molhos Especiais",
      description: "6x Hambúrgueres + 500g de Fritas + 500g Nuggets + 2x Coca-Cola 2 Litros + 4 Molhos Especiais. 2x Classic Costela, 2x Classic Cheddar, 1x Classic Salada, 1x Classic Smash",
      price: 149.90,
      discountedPrice: 68.90,
      image: "https://qburguerpedidos.site/pedir/images/burz20.png",
      categoryId: "combos-especiais", 
      featured: true,
      badge: dynamicBadges.combo3.badge,
      urgency: dynamicBadges.combo3.urgency,
      specialStyle: true,
      badgeColor: "red"
    },
    {
      id: "combo4",
      name: "COMBO TRIO SMASH - 3x Classic Smash Burguer + 500g Fritas + Coca-Cola 2 Litros",
      description: "3x Classic Smash Burguer + 500g Fritas + Coca-Cola 2 Litros. 2x Smash Burguer 100g (cada), Molho Cheddar, Cebola Picada, Bacon, Maionese temperada, Pão de Brioche com Gergelim.",
      price: 89.90,
      discountedPrice: 37.90,
      image: "https://qburguerpedidos.site/pedir/images/burgz21.png",
      categoryId: "combos-especiais",
      featured: false,
      badge: dynamicBadges.combo4.badge,
      urgency: dynamicBadges.combo4.urgency,
      specialStyle: false,
      badgeColor: "orange"
    },
    {
      id: "combo5",
      name: "COMBO SOLTEIRO - 1x Classic Chicken Cheese + Coca-Cola Lata + 500g Fritas + 500g de Frango Frito",
      description: "1x Classic Chicken Cheese + Coca-Cola Lata + 500g Fritas + 500g de Frango Frito. Deliciosa Sobrecoxa de Frango empanada 200g, Bacon, Maionese temperada, Alface, Pão de Brioche.",
      price: 69.90,
      discountedPrice: 25.90,
      image: "https://qburguerpedidos.site/pedir/images/burgz23.png",
      categoryId: "combos-especiais",
      featured: false,
      badge: dynamicBadges.combo5.badge,
      urgency: dynamicBadges.combo5.urgency,
      specialStyle: false,
      badgeColor: "green"
    },
    {
      id: "combo6",
      name: "Combo Classic Cheddar Individual + Coca-Cola + Fritas",
      description: "Combo Classic Cheddar individual + Coca-Cola + Fritas. Hamburguer 200g, Creme de Cheddar, Bacon, Catupiry, Cebola Caramelizada, Pão Australiano com Gergelim.",
      price: 39.90,
      discountedPrice: 17.80,
      image: "https://qburguerpedidos.site/pedir/images/burgz1.png",
      categoryId: "combos-especiais",
      featured: false,
      badge: dynamicBadges.combo6.badge,
      urgency: dynamicBadges.combo6.urgency,
      specialStyle: false,
      badgeColor: "blue"
    },
    {
      id: "combo7",
      name: "2x Combo Classic Salada + 2 Coca-Colas + Fritas",
      description: "2x Combo Classic Salada + 2 Coca-Colas + Fritas. Hamburguer 200g, Queijo Cheddar, Bacon, Alface, Tomate, Cebola, Pão de Brioche com Gergelim.",
      price: 69.90,
      discountedPrice: 27.90,
      image: "https://qburguerpedidos.site/pedir/images/burgz4.png",
      categoryId: "combos-especiais",
      featured: false,
      badge: dynamicBadges.combo7.badge,
      urgency: dynamicBadges.combo7.urgency,
      specialStyle: false,
      badgeColor: "pink"
    },
    {
      id: "combo8",
      name: "Combo de Fritas + Frango Frito + Nuggets + 2 Coca-Colas",
      description: "350g das nossas deliciosas Batatas Fritas + 8 pedaços do nosso delicioso Frango Frito com receita especial da casa + 15 Nuggets quentinhos!! Acompanhados de 2 Coca-Colas geladas pra completar o combo perfeito!😋😋",
      price: 79.90,
      discountedPrice: 39.80,
      image: "https://qburguerpedidos.site/pedir/images/burgz9.png",
      categoryId: "combos-especiais",
      featured: false,
      badge: dynamicBadges.combo8.badge,
      socialProof: dynamicBadges.combo8.socialProof,
      scarcity: dynamicBadges.combo8.scarcity,
      specialStyle: false,
      badgeColor: "purple"
    }
  ];
  
  // Combinar todos os produtos dentro do componente
  const allProducts = [...dynamicCombosEspeciais, ...products];
  
  // Atualização automática à meia-noite
  useEffect(() => {
    const checkDayChange = () => {
      const now = new Date();
      const midnight = new Date();
      midnight.setHours(24, 0, 0, 0);
      
      const timeUntilMidnight = midnight.getTime() - now.getTime();
      
      setTimeout(() => {
        // Força re-render ao chegar meia-noite
        window.location.reload();
      }, timeUntilMidnight);
    };
    
    checkDayChange();
  }, []);

  // Verificar localStorage para localização ao montar componente
  useEffect(() => {
    // APENAS PARA TESTES: Limpar o localStorage para garantir que o modal apareça
    localStorage.removeItem('user_address');
    console.log('localStorage limpo para testes');
    
    // Simular tempo de carregamento
    const loadTimer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    
    // Verificar se o usuário já selecionou localização
    const savedAddress = localStorage.getItem('user_address');
    console.log('Verificando localização salva:', savedAddress);
    
    if (!savedAddress) {
      console.log('Nenhuma localização encontrada, exibindo modal');
      setShowLocationModal(true);
      setShowMenu(false); // Esconder o cardápio inicialmente
    } else {
      console.log('Localização encontrada, não exibindo modal');
      setUserAddress(JSON.parse(savedAddress)); // Armazenar o endereço salvo
      setShowMenu(true); // Mostrar o cardápio se já tiver localização
    }
    
    return () => clearTimeout(loadTimer);
  }, []);

  // Função chamada quando o usuário confirma sua localização
  const handleLocationConfirmed = (addressData: AddressData) => {
    setUserAddress(addressData); // Salvar endereço no estado
    setShowLocationModal(false);
    setShowMenu(true); // Mostrar o cardápio quando o usuário confirmar a localização
  };

  // Função para forçar a exibição do modal de localização
  const forceShowLocationModal = () => {
    // Limpar o localStorage
    localStorage.removeItem('user_address');
    // Exibir o modal
    setShowLocationModal(true);
    // Esconder o cardápio
    setShowMenu(false);
  };

  // Observador para detectar qual categoria está visível
  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '-100px 0px -50% 0px',
      threshold: 0
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setSelectedCategory(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    // Observar todas as seções de categoria
    Object.values(categoryRefs.current).forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    const element = categoryRefs.current[categoryId];
    if (element) {
      const headerHeight = 73; // altura do header
      const navHeight = 57; // altura da nav
      const offset = headerHeight + navHeight + 16; // 16px de margem extra
      
      const elementPosition = element.offsetTop - offset;
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleViewDetails = (productId: string) => {
    const product = allProducts.find(p => p.id === productId);
    if (product) {
      setSelectedProduct(product.id);
    }
  };

  const handleAddToCart = (item: CartItem) => {
    addToCart(item);
    
    setSelectedProduct(null);
    toast({
      title: "Adicionado ao carrinho",
      description: `${item.name} foi adicionado ao carrinho`,
    });
  };

  const getProductsByCategory = (categoryId: string) => {
    return allProducts.filter(product => product.categoryId === categoryId);
  };

  const getFeaturedProducts = () => {
    return allProducts.filter(product => product.featured);
  };

  // Mostrar o skeleton loader enquanto os dados estão sendo carregados
  if (loading) {
    return <MenuSkeleton />;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      
      {/* Conteúdo do cardápio - visível apenas quando showMenu for true */}
      <div className={`transition-all duration-500 ${showMenu ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <CategoryNav 
          categories={categories}
          activeCategory={selectedCategory}
          onCategoryClick={handleCategoryClick}
        />

        {/* Featured Products Carousel */}
        <div className="pb-4 pt-3">
          <FeaturedCarousel 
            products={getFeaturedProducts()} 
            onViewDetails={handleViewDetails}
          />
        </div>

        <main className="pb-8">
          {/* COMBOS ESPECIAIS - PRIORIDADE MÁXIMA */}
          <section
            id="combos-especiais"
            ref={(el: HTMLDivElement | null) => { categoryRefs.current['combos-especiais'] = el; }}
            className="px-4 py-6 bg-gradient-to-b from-orange-50/30 to-transparent"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">
                🔥 COMBOS ESPECIAIS 🔥
              </h2>
              
              {/* Indicador do dia atual */}
              <div className="bg-primary/10 border border-primary/20 rounded-lg px-4 py-2 mb-4 inline-block">
                <span className="text-primary font-bold text-sm">
                  📅 OFERTAS DE {dayInfo.dayName} - {dayInfo.isWeekend ? 'FINAL DE SEMANA' : 'DIA DE SEMANA'}
                </span>
              </div>
              
              {/* Urgência temporal */}
              <div className="bg-yellow-100/50 border border-yellow-200 rounded-lg px-4 py-2 inline-block">
                <span className="text-yellow-800 font-bold text-sm">
                  {timeUrgency}
                </span>
              </div>
            </div>
            
            <div className="space-y-4">
              {getProductsByCategory('combos-especiais').map((combo) => (
                <ComboSpecialCard key={combo.id} combo={combo as any} onViewDetails={handleViewDetails} />
              ))}
            </div>
          </section>
          
          {/* Resto das categorias */}
          {categories.filter(category => category.id !== "combos-especiais").map((category) => {
            const categoryProducts = getProductsByCategory(category.id);
            
            if (categoryProducts.length === 0) {
              return null;
            }
            
            return (
              <section
                key={category.id}
                id={category.id}
                ref={(el: HTMLDivElement | null) => { categoryRefs.current[category.id] = el; }}
                className="px-4 py-4"
                style={{ scrollMarginTop: '130px' }} // Para ajustar o scroll ao clicar nas categorias
              >
                <h2 className="text-lg font-bold text-foreground mb-4 flex items-center">
                  <span className="text-primary underline decoration-2 underline-offset-4">
                    {category.name}
                  </span>
                </h2>
                
                <div className="space-y-3">
                  {categoryProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      id={product.id}
                      name={product.name}
                      description={product.description}
                      price={product.price}
                      discountedPrice={product.discountedPrice}
                      image={product.image}
                      onViewDetails={handleViewDetails}
                    />
                  ))}
                </div>
              </section>
            );
          })}
        </main>
        
        {/* Seção de Avaliações - Final da Página */}
        <ReviewsSection />
      </div>

      {/* Product Details Modal */}
      {selectedProduct && (
        <ProductDetails
          product={allProducts.find(p => p.id === selectedProduct)}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Renderizar o ModernLocationModal */}
      <ModernLocationModal 
        isOpen={showLocationModal}
        onClose={() => {
          // Só fechar se já tiver um endereço salvo
          if (userAddress) {
            setShowLocationModal(false);
            setShowMenu(true);
          }
        }}
        onLocationConfirmed={handleLocationConfirmed}
      />
    </div>
  );
}