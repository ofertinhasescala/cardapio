// Constantes da aplicação

// Google Maps API Key - Chave sem restrições de domínio para desenvolvimento
export const GOOGLE_MAPS_API_KEY = 'AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao';

// Outras constantes da aplicação
export const APP_NAME = 'Óia Push';
export const CURRENCY_FORMAT = 'pt-BR';

// Configurações de tempo
export const ESTIMATED_DELIVERY_TIME = '30-45 min';

// Valores padrão
export const DEFAULT_DELIVERY_FEE = 5.00; 